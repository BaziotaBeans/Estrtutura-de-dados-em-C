/*----------------------------------------------------------------------
    Directrizes de pre-processamento
-----------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include "Bibliotecas/lista_sequencial.h"
/*----------------------------------------------------------------------
    Funcao Principal
-----------------------------------------------------------------------*/
void main ()
{
    TListaSequencial lista = (TListaSequencial) malloc (sizeof (TListaSequencial));
    TItem elemento = (TItem) malloc (sizeof (TItem));
    printf ("\nSize: %lfbytes.\n", sizeof (TListaSequencial));
    /*
    inicializar (lista);
    criarItem (elemento);
    inserir (lista, elemento);
    criarItem (elemento);
    inserir (lista, elemento);
    criarItem (elemento);
    inserir (lista, elemento);
    criarItem (elemento);
    inserir (lista, elemento);
    criarItem (elemento);
    inserir (lista, elemento);
    imprimirElementos (lista);
    */
    free (lista);
    free (elemento);
}
/*----------------------------------------------------------------------
    Definicao de Funcoes
-----------------------------------------------------------------------*/
