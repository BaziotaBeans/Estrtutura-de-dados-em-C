/*--------------------------------------------------------------------------------
        Directrizes de Pre-Processamento
--------------------------------------------------------------------------------*/
#include "lista_sequencial.h"
#include <stdio.h>

#define INICIALIZAR -1
#define ITEM_NAO_ENCONTRADO -1
#define OPERACAO_EFECTUADA 0
#define LISTA_VAZIA 1
#define LISTA_CHEIA 2
#define INDICE_INVALIDO 3
#define TAMANHO 10
/*--------------------------------------------------------------------------------
        Estruturas de Dados
--------------------------------------------------------------------------------*/
struct Item 
{
    int chave, valor;
};

struct ListaSequencial
{
    Item info [TAMANHO];
    int ultimaPosicao;
};
/*--------------------------------------------------------------------------------
        Definicao de Funcoes
--------------------------------------------------------------------------------*/
void inicializar (TListaSequencial lista)
{
    lista->ultimaPosicao = INICIALIZAR;
}

boolean vazia (TListaSequencial lista)
{
    return (lista->ultimaPosicao == INICIALIZAR);
}

boolean cheia (TListaSequencial lista)
{
    return (lista->ultimaPosicao == TAMANHO - 1);
}

int criarItem (TItem item)
{
    int chave, valor;
    printf ("\nIntroduza a chave e o valor do item que pretende criar: ");
    scanf ("%d %d", &chave, &valor);
    item->chave = chave;
    item->valor = valor;
    return OPERACAO_EFECTUADA;
}

int consultarElemento (TListaSequencial lista, int posicao, TItem x)
{
    if (vazia (lista)) return LISTA_VAZIA;
    if (posicao < 0 || posicao > lista->ultimaPosicao) return INDICE_INVALIDO;
    x = lista->info[posicao];
    return OPERACAO_EFECTUADA;
}

int BuscarElemento (TListaSequencial lista, TItem x)
{
    if (vazia (lista)) return LISTA_VAZIA;
    for (int posicao = 0; posicao <= lista->ultimaPosicao; posicao++)
        if (lista->info[posicao]->chave == x->chave)
            return posicao;
    return ITEM_NAO_ENCONTRADO;
}

int inserir (TListaSequencial lista, TItem elemento)
{
    if (cheia (lista)) return LISTA_CHEIA;
    lista->info [++lista->ultimaPosicao] = elemento;
    return OPERACAO_EFECTUADA;
}

int inserirElemento (TListaSequencial lista, int posicao, TItem x)
{
    if (cheia (lista)) return LISTA_CHEIA;
    if (posicao < 0 || posicao > lista->ultimaPosicao) return INDICE_INVALIDO;
    for (int posicao_auxiliar = lista->ultimaPosicao; posicao_auxiliar >= posicao; posicao_auxiliar--)
        lista->info[posicao_auxiliar] = lista->info[posicao_auxiliar + 1];
    lista->info[posicao] = x;
    lista->ultimaPosicao++;
    return OPERACAO_EFECTUADA;
}

int removerElemento (TListaSequencial lista, int posicao, TItem x)
{
    if (vazia(lista)) return LISTA_VAZIA;
    if (posicao < 0 || posicao > lista->ultimaPosicao) return INDICE_INVALIDO;
    for (int posicao_auxiliar = posicao; posicao_auxiliar < lista->ultimaPosicao; posicao_auxiliar++)
        lista->info[posicao_auxiliar] = lista->info[posicao_auxiliar + 1];
    lista->ultimaPosicao--;
    return OPERACAO_EFECTUADA;
}

int imprimirElementos (TListaSequencial lista)
{
    if (vazia(lista)) return LISTA_VAZIA;
    for (int posicao = 0; posicao <= lista->ultimaPosicao; posicao++)
        printf (" %d", lista->info[posicao]->valor);
    printf ("\n");
    return OPERACAO_EFECTUADA;
}

void mensagem (int codigo)
{
    switch (codigo)
    {
        case ITEM_NAO_ENCONTRADO:
            printf ("Erro!Item não encontrado.\n");
            break;
        case LISTA_VAZIA:
            printf ("Erro!A Lista está vazia.\n");
            break;
        case LISTA_CHEIA:
            printf ("Erro!A lista está cheia.\n");
            break;
        case INDICE_INVALIDO:
            printf ("Erro!Indíce inválido.\n");
            break;
        default:
            printf ("Operação efectuada.\n");
    }
}