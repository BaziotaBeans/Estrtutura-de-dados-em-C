/*----------------------------------------------------------------
            Directrizes de Pre-Processamento
----------------------------------------------------------------*/
#ifndef LISTA_SEQUENCIAL
#define LISTA_SEQUENCIAL

#define INICIALIZAR -1
#define ITEM_NAO_ENCONTRADO -1
#define OPERACAO_EFECTUADA 0
#define LISTA_VAZIA 1
#define LISTA_CHEIA 2
#define INDICE_INVALIDO 3

#define TAMANHO 10
/*----------------------------------------------------------------
            Estruturas de Dados
----------------------------------------------------------------*/
typedef enum {false, true} boolean;

typedef struct
{
    int chave, valor;
}TItem;

typedef struct 
{
    TItem info [TAMANHO];
    int ultPosicao;
}TListaSequencial;
/*----------------------------------------------------------------
            Prototipos de Funcoes
----------------------------------------------------------------*/
void inicializar (TListaSequencial *lista);

boolean vazia (TListaSequencial lista);

boolean cheia (TListaSequencial lista);

int criarItem (TItem *item);

int consultarElemento (TListaSequencial lista, int posicao, TItem *x);

int BuscarElemento (TListaSequencial lista, TItem x);

int inserir (TListaSequencial *lista, TItem elemento);

int inserirElemento (TListaSequencial *lista, int posicao, TItem x);

int removerElemento (TListaSequencial *lista, int posicao, TItem x);

int imprimirElementos (TListaSequencial lista);

#endif 