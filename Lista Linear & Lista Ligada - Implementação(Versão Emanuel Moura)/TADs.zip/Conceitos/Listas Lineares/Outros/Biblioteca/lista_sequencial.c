/*--------------------------------------------------------------------------------
        Directrizes de Pre-Processamento
--------------------------------------------------------------------------------*/
#include "lista_sequencial.h"
#include "stdio.h"

/*--------------------------------------------------------------------------------
        Definicao de Funcoes
--------------------------------------------------------------------------------*/
void inicializar (TListaSequencial *lista)
{
    lista->ultPosicao = INICIALIZAR;
}

boolean vazia (TListaSequencial lista)
{
    return (lista.ultPosicao == INICIALIZAR);
}

boolean cheia (TListaSequencial lista)
{
    return (lista.ultPosicao == TAMANHO - 1);
}

int criarItem (TItem *item)
{
    printf ("\nIntroduza a chave e o valor do item que pretende criar: ");
    scanf ("%d %d", &(item->chave), &(item->valor));
    return OPERACAO_EFECTUADA;
}

int consultarElemento (TListaSequencial lista, int posicao, TItem *x)
{
    if (vazia (lista)) return LISTA_VAZIA;
    if (posicao < 0 || posicao > lista.ultPosicao) return INDICE_INVALIDO;
    *x = lista.info[posicao];
    return OPERACAO_EFECTUADA;
}

int BuscarElemento (TListaSequencial lista, TItem x)
{
    if (vazia (lista)) return LISTA_VAZIA;
    for (int posicao = 0; posicao <= lista.ultPosicao; posicao++)
        if (lista.info[posicao].chave == x.chave)
            return posicao;
    return ITEM_NAO_ENCONTRADO;
}

int inserir (TListaSequencial *lista, TItem elemento)
{
    if (cheia (*lista)) return LISTA_CHEIA;
    lista->info [++lista->ultPosicao] = elemento;
    return OPERACAO_EFECTUADA;
}

int inserirElemento (TListaSequencial *lista, int posicao, TItem x)
{
    if (cheia (*lista)) return LISTA_CHEIA;
	if (posicao < 0 || posicao > lista->ultPosicao) return INDICE_INVALIDO;
    for (int posicao_auxiliar = lista->ultPosicao; posicao_auxiliar >= posicao; posicao_auxiliar--)
        lista->info[posicao_auxiliar] = lista->info[posicao_auxiliar + 1];
    lista->info[posicao] = x;
    lista->ultPosicao++;
    return OPERACAO_EFECTUADA;
}

int removerElemento (TListaSequencial *lista, int posicao, TItem x)
{
    if (vazia(*lista)) return LISTA_VAZIA;
    if (posicao < 0 || posicao > lista->ultPosicao) return INDICE_INVALIDO;
    for (int posicao_auxiliar = posicao; posicao_auxiliar < lista->ultPosicao; posicao_auxiliar++)
        lista->info[posicao_auxiliar] = lista->info[posicao_auxiliar + 1];
    lista->ultPosicao--;
    return OPERACAO_EFECTUADA;
}

int imprimirElementos (TListaSequencial lista)
{
    if (vazia(lista)) return LISTA_VAZIA;
    while (lista.ultPosicao >= 0)
        printf (" %d", lista.info[lista.ultPosicao--].valor);
    printf ("\n");
    return OPERACAO_EFECTUADA;
}

void mensagem (int codigo)
{
    switch (codigo)
    {
        case ITEM_NAO_ENCONTRADO:
            printf ("Erro!Item não encontrado.\n");
            break;
        case LISTA_VAZIA:
            printf ("Erro!A Lista está vazia.\n");
            break;
        case LISTA_CHEIA:
            printf ("Erro!A lista está cheia.\n");
            break;
        case INDICE_INVALIDO:
            printf ("Erro!Indíce inválido.\n");
            break;
        default:
            printf ("Operação efectuada.\n");
    }
}