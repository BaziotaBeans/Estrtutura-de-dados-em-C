#include <stdio.h>
#include "Biblioteca/lista_sequencial.h"


void main ()
{
    TListaSequencial lista;	
	TItem elemento;
	inicializar (&lista);
    criarItem (&elemento);
    inserir (&lista, elemento);
    criarItem (&elemento);
    inserir (&lista, elemento);
    criarItem (&elemento);
    inserir (&lista, elemento);
    criarItem (&elemento);
    inserir (&lista, elemento);
    criarItem (&elemento);
    inserir (&lista, elemento);
    imprimirElementos (lista);
}