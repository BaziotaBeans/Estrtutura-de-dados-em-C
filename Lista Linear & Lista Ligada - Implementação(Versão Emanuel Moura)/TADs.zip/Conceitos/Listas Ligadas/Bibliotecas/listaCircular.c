/*-------------------------------------------------------------------------
			Directrizes de Pre-Processamento
-------------------------------------------------------------------------*/
#include "listaCircular.h"
#include <stdio.h>
#include <stdlib.h>
#define OPERACAO_EFECTUADA 0
#define LISTA_VAZIA 1
#define MEMORIA_CHEIA 2
#define NAO_ENCONTRADO 3

/*-------------------------------------------------------------------------
			Definicao de Estruturas
-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------
			Definicao de Funcoes
-------------------------------------------------------------------------*/
void inicializar (TListaCircular *lista)
{
	lista->primeiro = NULL;
}

boolean vazia (TListaCircular lista)
{
	return (lista.primeiro == NULL);
}

void criarInfo (TInfo *info)
{
	printf ("\nIntroduza a chave e o valor do item que pretende criar: ");
    scanf ("%d %d", &(info->chave), &(info->valor));
}

int inserir (TListaCircular *lista, TInfo info)
{
	TAtomo *novoElemento = (TAtomo *) malloc (sizeof (TAtomo));
	if (novoElemento == NULL) return MEMORIA_CHEIA;
	novoElemento->info = info;
	if (vazia(*lista)) 
		lista->primeiro = novoElemento;
	else 
		novoElemento->proximo = lista->primeiro->proximo;
	lista->primeiro->proximo = novoElemento;
	return OPERACAO_EFECTUADA;
}

int removerAtomoChave (TListaCircular *lista, int chave)
{
	if (vazia (*lista)) return LISTA_VAZIA;
	TAtomo *remover = lista->primeiro;
	if (remover == remover->proximo)
	{
		free (remover);
		inicializar (&*lista);
	}
	else
	{
		while (remover->proximo->info.chave != chave && remover->proximo != lista->primeiro) remover = remover->proximo;
		if (remover->proximo->info.chave != chave) return NAO_ENCONTRADO;
		if (remover->proximo == lista->primeiro) lista->primeiro = lista->primeiro->proximo;
		TAtomo *liberar = (TAtomo *) malloc (sizeof (TAtomo));
		remover->proximo = remover->proximo->proximo;
		free (liberar);	
	}
	
	return OPERACAO_EFECTUADA;
}

void imprimir (TListaCircular lista)
{
	for (TAtomo *elemento = lista.primeiro; elemento != NULL; elemento = elemento->proximo)
	{
		printf ("\nValor: %d Chave: %d", elemento->info.valor, elemento->info.chave);
		if (elemento->proximo == lista.primeiro) break;
	}	
}