/*-------------------------------------------------------------------------
			Directrizes de Pre-Processamento
-------------------------------------------------------------------------*/
#include "listaDupla.h"
#include <stdio.h>
#include <stdlib.h>
#define OPERACAO_EFECTUADA 0
#define LISTA_VAZIA 1
#define MEMORIA_CHEIA 2
#define NAO_ENCONTRADO 3

/*-------------------------------------------------------------------------
			Definicao de Estruturas
-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------
			Definicao de Funcoes
-------------------------------------------------------------------------*/
void inicializar (TListaDupla *lista)
{
	lista->primeiro = NULL;
	lista->ultimo = NULL;
}

boolean vazia (TListaDupla lista)
{
	return (lista.primeiro == NULL);
}

void criarInfo (TInfo *info)
{
	printf ("\nIntroduza a chave e o valor do item que pretende criar: ");
    scanf ("%d %d", &(info->chave), &(info->valor));
}

int inserir (TListaDupla *lista, TInfo info)
{
	TAtomo *novoElemento = (TAtomo *) malloc (sizeof (TAtomo));
	if (novoElemento == NULL) return MEMORIA_CHEIA;
	novoElemento->info = info;
	novoElemento->proximo = NULL;
	if (lista->primeiro == NULL)
	{
		novoElemento->anterior = NULL;
		lista->primeiro = novoElemento;
	}	
	else 
	{
		novoElemento->anterior = lista->ultimo;
		lista->ultimo->proximo = novoElemento;
	}
	lista->ultimo = novoElemento;
	return OPERACAO_EFECTUADA;
}

int removerAtomoChave (TListaDupla *lista, int chave)
{
	if (vazia (*lista)) return LISTA_VAZIA;
	TAtomo *remover = lista->primeiro;
	if (remover == NULL) return MEMORIA_CHEIA;
	while (remover != NULL && remover->info.chave != chave) remover = remover->proximo;
	if (remover == NULL) return NAO_ENCONTRADO;
	if (remover == lista->ultimo) 
	{
		lista->ultimo = remover->anterior;
		lista->ultimo->proximo = NULL;
	}
	else if (remover == lista->primeiro) 
	{
		lista->primeiro = remover->proximo;
		lista->primeiro->anterior = NULL;
	}
	else
	{
		remover->anterior->proximo = remover->proximo;
		remover->proximo->anterior = remover->anterior;	
	}
	free (remover);
	return OPERACAO_EFECTUADA;
}

void imprimir (TListaDupla lista)
{
	for (TAtomo *elemento = lista.primeiro; elemento != NULL; elemento = elemento->proximo)
		printf ("\nValor: %d Chave: %d", elemento->info.valor, elemento->info.chave);
}