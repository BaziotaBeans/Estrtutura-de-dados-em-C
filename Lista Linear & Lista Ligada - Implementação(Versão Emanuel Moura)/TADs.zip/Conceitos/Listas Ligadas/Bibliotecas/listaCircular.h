/*-------------------------------------------------------------------------
			Directrizes de Pre-Processamento
-------------------------------------------------------------------------*/
#ifndef LISTA_CIRCULAR
#define LISTA_CIRCULAR
/*-------------------------------------------------------------------------
			Definicao de Estruturas/Registros
-------------------------------------------------------------------------*/
typedef enum {false, true} boolean;

typedef struct
{
	int chave, valor;
}TInfo;

typedef struct Atomo
{
	TInfo info;
	struct Atomo *proximo;
}TAtomo;

typedef struct 
{
	TAtomo *primeiro;
}TListaCircular;
/*-------------------------------------------------------------------------
			Prototipos de Funcoes
-------------------------------------------------------------------------*/
void inicializar (TListaCircular *lista);

boolean vazia (TListaCircular lista);

void criarInfo (TInfo *info);

int inserir (TListaCircular *lista, TInfo info);

void imprimir (TListaCircular lista);

int removerAtomoChave (TListaCircular *lista, int chave);

#endif 