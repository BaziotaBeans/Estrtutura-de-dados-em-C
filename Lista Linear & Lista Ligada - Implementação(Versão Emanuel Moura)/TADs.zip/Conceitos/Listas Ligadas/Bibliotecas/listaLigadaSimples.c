/*-------------------------------------------------------------------------
			Directrizes de Pre-Processamento
-------------------------------------------------------------------------*/
#include "listaLigadaSimples.h"
#include <stdio.h>
#include <stdlib.h>
#define OPERACAO_EFECTUADA 0
#define LISTA_VAZIA 1
#define MEMORIA_CHEIA 2
#define NAO_ENCONTRADO 3

/*-------------------------------------------------------------------------
			Definicao de Estruturas
-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------
			Definicao de Funcoes
-------------------------------------------------------------------------*/
void inicializar (TListaLigadaSimples *lista)
{
	lista->primeiro = NULL;
	lista->ultimo = NULL;
}

boolean vazia (TListaLigadaSimples lista)
{
	return (lista.primeiro == NULL);
}

void criarInfo (TInfo *info)
{
	printf ("\nIntroduza a chave e o valor do item que pretende criar: ");
    scanf ("%d %d", &(info->chave), &(info->valor));
}

int inserir (TListaLigadaSimples *lista, TInfo info)
{
	TAtomo *novoAtomo = (TAtomo *) malloc (sizeof (TAtomo));
	if (novoAtomo == NULL) return MEMORIA_CHEIA;
	novoAtomo->info = info;
	novoAtomo->proximo = NULL;
	if (lista->primeiro == NULL) lista->primeiro = novoAtomo;
	else lista->ultimo->proximo = novoAtomo;
	lista->ultimo = novoAtomo;
	return OPERACAO_EFECTUADA;
}

int removerAtomoChave (TListaLigadaSimples *lista, int chave)
{
	if (vazia (*lista)) return LISTA_VAZIA;
	TAtomo *elemento = lista->primeiro;
	if (elemento->info.chave == chave)
		lista->primeiro = lista->primeiro->proximo;
	else
	{
		while (elemento != NULL && elemento->proximo->info.chave != chave)
			elemento = elemento->proximo;
		if (elemento == NULL) return NAO_ENCONTRADO;
		if (elemento->proximo == lista->ultimo) lista->ultimo = elemento;
		TAtomo *liberar = elemento->proximo; 
		elemento->proximo = elemento->proximo->proximo;
		free (liberar);
	}
	return OPERACAO_EFECTUADA;
}

void imprimir (TListaLigadaSimples lista)
{
	for (TAtomo *posicao = lista.primeiro; posicao != NULL; posicao = posicao->proximo)
		printf (" %d", posicao->info.valor);
}