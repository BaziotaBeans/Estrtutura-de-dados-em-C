/*-------------------------------------------------------------------------
			Directrizes de Pre-Processamento
-------------------------------------------------------------------------*/
#ifndef LISTA_COM_CABECA
#define LISTA_COM_CABECA
/*-------------------------------------------------------------------------
			Definicao de Estruturas/Registros
-------------------------------------------------------------------------*/
typedef enum {false, true} boolean;

typedef struct
{
	int chave, valor;
}TInfo;

typedef struct Atomo
{
	TInfo info;
	struct Atomo *proximo;
}TAtomo;

typedef struct 
{
	TAtomo *cabeca;
	TAtomo *ultimo;
}TListaComCabeca;
/*-------------------------------------------------------------------------
			Prototipos de Funcoes
-------------------------------------------------------------------------*/
int inicializar (TListaComCabeca *lista);

boolean vazia (TListaComCabeca lista);

void criarInfo (TInfo *info);

int inserir (TListaComCabeca *lista, TInfo info);

void imprimir (TListaComCabeca lista);

int removerAtomoChave (TListaComCabeca *lista, int chave);

#endif 