/*-------------------------------------------------------------------------
			Directrizes de Pre-Processamento
-------------------------------------------------------------------------*/
#ifndef LISTA_LIGADA_SIMPLES
#define LISTA_LIGADA_SIMPLES
/*-------------------------------------------------------------------------
			Definicao de Estruturas/Registros
-------------------------------------------------------------------------*/
typedef enum {false, true} boolean;

typedef struct
{
	int chave, valor;
}TInfo;

typedef struct Atomo
{
	TInfo info;
	struct Atomo *proximo;
}TAtomo;

typedef struct 
{
	TAtomo *primeiro;
	TAtomo *ultimo;
}TListaLigadaSimples;
/*-------------------------------------------------------------------------
			Prototipos de Funcoes
-------------------------------------------------------------------------*/
void inicializar (TListaLigadaSimples *lista);

boolean vazia (TListaLigadaSimples lista);

void criarInfo (TInfo *info);

int inserir (TListaLigadaSimples *lista, TInfo info);

void imprimir (TListaLigadaSimples lista);

int removerAtomoChave (TListaLigadaSimples *lista, int chave);

#endif 