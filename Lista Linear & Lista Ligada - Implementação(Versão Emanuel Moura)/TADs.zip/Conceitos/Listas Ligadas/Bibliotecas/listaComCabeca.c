/*-------------------------------------------------------------------------
			Directrizes de Pre-Processamento
-------------------------------------------------------------------------*/
#include "listaComCabeca.h"
#include <stdio.h>
#include <stdlib.h>
#define OPERACAO_EFECTUADA 0
#define LISTA_VAZIA 1
#define MEMORIA_CHEIA 2
#define NAO_ENCONTRADO 3

/*-------------------------------------------------------------------------
			Definicao de Estruturas
-------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------
			Definicao de Funcoes
-------------------------------------------------------------------------*/
int inicializar (TListaComCabeca *lista)
{
	TAtomo *inicializar = (TAtomo *) malloc (sizeof (TAtomo));
	if (inicializar == NULL) return MEMORIA_CHEIA;
	lista->cabeca = inicializar;
	lista->ultimo = NULL;
	lista->cabeca->proximo = NULL;
	return OPERACAO_EFECTUADA;
}

boolean vazia (TListaComCabeca lista)
{
	return (lista.cabeca->proximo == NULL);
}

int inserir (TListaComCabeca *lista, TInfo info)
{
	TAtomo *elemento = (TAtomo *) malloc (sizeof (TAtomo));
	if (elemento == NULL) return MEMORIA_CHEIA;
	elemento->info = info;
	if (vazia(*lista)) 
		lista->cabeca->proximo = elemento;
	else
		lista->ultimo->proximo = elemento;
	lista->ultimo = elemento;
	return OPERACAO_EFECTUADA;
}

void criarInfo (TInfo *info)
{
	printf ("\nIntroduza a chave e o valor do item que pretende criar: ");
    scanf ("%d %d", &(info->chave), &(info->valor));
}

int removerAtomoChave (TListaComCabeca *lista, int chave)
{
	if (vazia (*lista)) return LISTA_VAZIA;
	TAtomo *elemento = lista->cabeca;
	while (elemento != NULL && elemento->proximo->info.chave != chave)
		elemento = elemento->proximo;
	if (elemento == NULL) return NAO_ENCONTRADO;
	if (elemento->proximo == lista->ultimo) lista->ultimo = elemento;
	TAtomo *liberar = elemento->proximo; 
	elemento->proximo = elemento->proximo->proximo;
	free (liberar);
	return OPERACAO_EFECTUADA;
}

void imprimir (TListaComCabeca lista)
{
	for (TAtomo *elemento = lista.cabeca->proximo; elemento != NULL; elemento = elemento->proximo)
		printf ("\nChave: %d Valor: %d.", elemento->info.chave, elemento->info.valor);
}
