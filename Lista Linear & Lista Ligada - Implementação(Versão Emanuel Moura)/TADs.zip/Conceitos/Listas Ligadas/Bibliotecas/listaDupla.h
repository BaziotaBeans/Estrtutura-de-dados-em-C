/*-------------------------------------------------------------------------
			Directrizes de Pre-Processamento
-------------------------------------------------------------------------*/
#ifndef LISTA_DUPLAMENTE_LIGADA
#define LISTA_DUPLAMENTE_LIGADA
/*-------------------------------------------------------------------------
			Definicao de Estruturas/Registros
-------------------------------------------------------------------------*/
typedef enum {false, true} boolean;

typedef struct
{
	int chave, valor;
}TInfo;

typedef struct Atomo
{
	TInfo info;
	struct Atomo *proximo, *anterior;
}TAtomo;

typedef struct 
{
	TAtomo *primeiro;
	TAtomo *ultimo;
}TListaDupla;
/*-------------------------------------------------------------------------
			Prototipos de Funcoes
-------------------------------------------------------------------------*/
void inicializar (TListaDupla *lista);

boolean vazia (TListaDupla lista);

void criarInfo (TInfo *info);

int inserir (TListaDupla *lista, TInfo info);

void imprimir (TListaDupla lista);

int removerAtomoChave (TListaDupla *lista, int chave);

#endif 